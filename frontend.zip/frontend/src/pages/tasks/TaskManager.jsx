import { useState, useEffect, useCallback } from 'react';
import api from '../../api/axios';
import toast from 'react-hot-toast';
import { PageSpinner } from '../../components/ui/Spinner';
import EmptyState from '../../components/ui/EmptyState';
import Modal from '../../components/ui/Modal';
import CountdownTimer from '../../components/ui/CountdownTimer';
import Badge from '../../components/ui/Badge';
import { Plus, Trash2, CheckSquare, Clock, Loader, ChevronDown, Filter } from 'lucide-react';
import { formatDate } from '../../utils/formatDate';

const STATUS_TABS = [
  { value: '', label: 'All' },
  { value: 'pending', label: 'Pending' },
  { value: 'in-progress', label: 'In Progress' },
  { value: 'completed', label: 'Completed' },
];

const PRIORITIES = ['low', 'medium', 'high'];

const PRIORITY_COLORS = {
  low: 'accent',
  medium: 'warning',
  high: 'danger',
};

const STATUS_COLORS = {
  pending: 'default',
  'in-progress': 'blue',
  completed: 'accent',
};

const NEXT_STATUS = {
  pending: 'in-progress',
  'in-progress': 'completed',
  completed: 'pending',
};

const TaskManager = () => {
  const [tasks, setTasks] = useState([]);
  const [stats, setStats] = useState({ pending: 0, 'in-progress': 0, completed: 0 });
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('');
  const [priority, setPriority] = useState('');
  const [subject, setSubject] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [updatingId, setUpdatingId] = useState(null);

  const [form, setForm] = useState({
    title: '',
    description: '',
    subject: '',
    deadline: '',
    priority: 'medium',
  });

  const fetchTasks = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (tab) params.set('status', tab);
      if (priority) params.set('priority', priority);
      if (subject) params.set('subject', subject);
      params.set('limit', '50');

      const [tasksRes, statsRes] = await Promise.all([
        api.get(`/api/tasks?${params}`),
        api.get('/api/tasks/stats'),
      ]);

      if (tasksRes.data.success) setTasks(tasksRes.data.data);
      if (statsRes.data.success) setStats(statsRes.data.data.stats);
    } catch {
      toast.error('Failed to load tasks');
    } finally {
      setLoading(false);
    }
  }, [tab, priority, subject]);

  useEffect(() => { fetchTasks(); }, [fetchTasks]);

  const handleCreate = async (e) => {
    e.preventDefault();
    if (!form.title.trim()) { toast.error('Title is required'); return; }
    setSubmitting(true);
    try {
      await api.post('/api/tasks', {
        ...form,
        deadline: form.deadline || undefined,
      });
      toast.success('Task created!');
      setShowAdd(false);
      setForm({ title: '', description: '', subject: '', deadline: '', priority: 'medium' });
      fetchTasks();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create task');
    } finally { setSubmitting(false); }
  };

  const handleDelete = async (id) => {
    try {
      await api.delete(`/api/tasks/${id}`);
      toast.success('Task deleted');
      fetchTasks();
    } catch { toast.error('Delete failed'); }
  };

  const handleStatusCycle = async (task) => {
    const nextStatus = NEXT_STATUS[task.status];
    setUpdatingId(task._id);
    try {
      await api.patch(`/api/tasks/${task._id}`, { status: nextStatus });
      fetchTasks();
    } catch { toast.error('Update failed'); }
    finally { setUpdatingId(null); }
  };

  const totalTasks = stats.pending + stats['in-progress'] + stats.completed;

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-header">My Tasks</h1>
          <p className="text-text-muted text-sm">Manage your academic tasks and deadlines</p>
        </div>
        <button onClick={() => setShowAdd(true)} className="btn-primary">
          <Plus size={16} /> New Task
        </button>
      </div>

      {/* Stats Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'Total', value: totalTasks, color: 'text-text-primary', bg: 'bg-surface-2' },
          { label: 'Pending', value: stats.pending, color: 'text-warning', bg: 'bg-warning/5' },
          { label: 'In Progress', value: stats['in-progress'], color: 'text-primary', bg: 'bg-primary/5' },
          { label: 'Completed', value: stats.completed, color: 'text-accent', bg: 'bg-accent/5' },
        ].map(({ label, value, color, bg }) => (
          <div key={label} className={`card-base ${bg} text-center py-3`}>
            <p className={`font-display text-2xl font-bold ${color}`}>{value}</p>
            <p className="text-text-muted text-xs mt-0.5">{label}</p>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 items-center">
        {/* Status Tabs */}
        <div className="flex gap-1 bg-surface p-1 rounded-xl border border-border">
          {STATUS_TABS.map(({ value, label }) => (
            <button key={value} onClick={() => setTab(value)}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${
                tab === value ? 'bg-primary text-white' : 'text-text-muted hover:text-text-primary'
              }`}>
              {label}
            </button>
          ))}
        </div>

        {/* Priority filter */}
        <select value={priority} onChange={e => setPriority(e.target.value)}
          className="input-base w-auto min-w-[130px] text-sm py-2">
          <option value="">All Priorities</option>
          {PRIORITIES.map(p => <option key={p} value={p}>{p.charAt(0).toUpperCase() + p.slice(1)}</option>)}
        </select>

        {/* Subject filter */}
        <input
          value={subject}
          onChange={e => setSubject(e.target.value)}
          placeholder="Filter by subject..."
          className="input-base w-auto min-w-[160px] text-sm py-2"
        />
      </div>

      {/* Task List */}
      {loading ? <PageSpinner /> : tasks.length === 0 ? (
        <EmptyState
          title="No tasks found"
          description="Create your first task to start tracking your academic work."
          action={<button onClick={() => setShowAdd(true)} className="btn-primary"><Plus size={16} /> New Task</button>}
        />
      ) : (
        <div className="space-y-2.5">
          {tasks.map((task) => (
            <div key={task._id} className={`card-base card-glow flex items-start gap-4 p-4 transition-all ${
              task.status === 'completed' ? 'opacity-60' : ''
            }`}>
              {/* Status Toggle Button */}
              <button
                onClick={() => handleStatusCycle(task)}
                disabled={updatingId === task._id}
                title={`Mark as ${NEXT_STATUS[task.status]}`}
                className={`mt-0.5 w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all ${
                  task.status === 'completed'
                    ? 'bg-accent border-accent text-white'
                    : task.status === 'in-progress'
                    ? 'border-primary bg-primary/10'
                    : 'border-border hover:border-primary'
                }`}
              >
                {updatingId === task._id ? (
                  <Loader size={10} className="animate-spin text-muted" />
                ) : task.status === 'completed' ? (
                  <CheckSquare size={10} />
                ) : task.status === 'in-progress' ? (
                  <Clock size={10} className="text-primary" />
                ) : null}
              </button>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <h3 className={`font-semibold text-sm ${task.status === 'completed' ? 'line-through text-text-muted' : 'text-text-primary'}`}>
                    {task.title}
                  </h3>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <Badge variant={PRIORITY_COLORS[task.priority]}>{task.priority}</Badge>
                    <Badge variant={STATUS_COLORS[task.status]}>{task.status}</Badge>
                  </div>
                </div>

                {task.description && (
                  <p className="text-text-muted text-xs mt-1 line-clamp-2">{task.description}</p>
                )}

                <div className="flex flex-wrap items-center gap-3 mt-2">
                  {task.subject && (
                    <span className="badge-base bg-surface-2 border border-border text-text-secondary text-[10px]">
                      {task.subject}
                    </span>
                  )}
                  {task.deadline && (
                    <div className="flex items-center gap-2">
                      <span className="text-text-muted text-[10px]">Due: {formatDate(task.deadline)}</span>
                      <CountdownTimer deadline={task.deadline} compact />
                    </div>
                  )}
                </div>
              </div>

              {/* Delete */}
              <button
                onClick={() => handleDelete(task._id)}
                className="p-1.5 rounded-lg text-muted hover:text-danger hover:bg-danger/5 transition-all flex-shrink-0"
              >
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Add Task Modal */}
      <Modal isOpen={showAdd} onClose={() => setShowAdd(false)} title="New Task">
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-text-secondary mb-1.5">Title *</label>
            <input
              value={form.title}
              onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
              placeholder="e.g. Complete Data Structures assignment"
              className="input-base"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-text-secondary mb-1.5">Description</label>
            <textarea
              value={form.description}
              onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
              placeholder="Optional details..."
              rows={2}
              className="input-base resize-none"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-text-secondary mb-1.5">Subject</label>
              <input
                value={form.subject}
                onChange={e => setForm(f => ({ ...f, subject: e.target.value }))}
                placeholder="e.g. Data Structures"
                className="input-base"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-text-secondary mb-1.5">Priority</label>
              <select value={form.priority} onChange={e => setForm(f => ({ ...f, priority: e.target.value }))} className="input-base">
                {PRIORITIES.map(p => <option key={p} value={p}>{p.charAt(0).toUpperCase() + p.slice(1)}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-text-secondary mb-1.5">Deadline</label>
            <input
              type="datetime-local"
              value={form.deadline}
              onChange={e => setForm(f => ({ ...f, deadline: e.target.value }))}
              className="input-base"
            />
          </div>
          <button type="submit" disabled={submitting} className="btn-primary w-full">
            {submitting ? <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : 'Create Task'}
          </button>
        </form>
      </Modal>
    </div>
  );
};

export default TaskManager;
