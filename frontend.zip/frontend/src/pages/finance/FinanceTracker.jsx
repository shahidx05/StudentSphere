import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import useFetch from '../../hooks/useFetch';
import api from '../../api/axios';
import toast from 'react-hot-toast';
import { PageSpinner } from '../../components/ui/Spinner';
import Badge from '../../components/ui/Badge';
import Pagination from '../../components/ui/Pagination';
import EmptyState from '../../components/ui/EmptyState';
import { Bar, Pie, Line } from 'react-chartjs-2';
import { formatCurrency } from '../../utils/formatCurrency';
import { formatDate } from '../../utils/formatDate';
import { FINANCE_CATEGORIES } from '../../utils/constants';
import { Plus, Trash2, TrendingUp, TrendingDown, Wallet, BarChart3, List, PlusCircle } from 'lucide-react';

const TABS = [
  { id: 'overview', label: 'Overview', icon: BarChart3 },
  { id: 'add', label: 'Add Entry', icon: PlusCircle },
  { id: 'history', label: 'History', icon: List },
];

const CATEGORY_COLORS_ARR = ['#FA4D56', '#F1C21B', '#0F62FE', '#42BE65', '#A78BFA', '#6F6F6F'];

const chartOptions = {
  responsive: true,
  plugins: { legend: { labels: { color: 'var(--text-secondary)', boxWidth: 12 } } },
  scales: {
    x: { grid: { color: 'var(--border)' }, ticks: { color: 'var(--text-muted)' } },
    y: { grid: { color: 'var(--border)' }, ticks: { color: 'var(--text-muted)' } },
  },
};

const FinanceTracker = () => {
  const navigate = useNavigate();
  const [tab, setTab] = useState('overview');
  const [page, setPage] = useState(1);
  const [typeFilter, setTypeFilter] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [deleteId, setDeleteId] = useState(null);
  const [form, setForm] = useState({
    type: 'expense',
    amount: '',
    category: 'food',
    description: '',
    date: new Date().toISOString().split('T')[0],
  });
  const [submitting, setSubmitting] = useState(false);

  // API fetches
  const txParams = new URLSearchParams({
    ...(typeFilter && { type: typeFilter }),
    ...(categoryFilter && { category: categoryFilter }),
    page, limit: 10,
  }).toString();

  const { data: txData, loading: txLoading, refetch } = useFetch(`/api/finance/transactions?${txParams}`);
  const { data: dailyData } = useFetch('/api/finance/summary/daily');
  const { data: monthlyData } = useFetch('/api/finance/summary/monthly');
  const { data: categoryData } = useFetch('/api/finance/analytics/category');
  const { data: yearlyData } = useFetch('/api/finance/summary/yearly');

  const txList = txData?.data || [];
  const pagination = txData?.pagination || {};
  const daily = dailyData?.data || {};
  const monthlyList = monthlyData?.data || [];
  const categories = categoryData?.data || [];
  const yearly = yearlyData?.data || [];

  const handleAdd = async (e) => {
    e.preventDefault();
    if (!form.amount || isNaN(Number(form.amount)) || Number(form.amount) <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }
    setSubmitting(true);
    try {
      await api.post('/api/finance/transactions', { ...form, amount: Number(form.amount) });
      toast.success('Transaction added!');
      setForm({ type: 'expense', amount: '', category: 'food', description: '', date: new Date().toISOString().split('T')[0] });
      setTab('history');
      refetch();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to add');
    } finally { setSubmitting(false); }
  };

  const handleDelete = async (id) => {
    try {
      await api.delete(`/api/finance/transactions/${id}`);
      toast.success('Deleted.');
      setDeleteId(null);
      refetch();
    } catch { toast.error('Delete failed'); }
  };

  // Chart: monthly bar
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const incomeByMonth = Array(12).fill(0);
  const expenseByMonth = Array(12).fill(0);
  yearly.forEach(({ _id, total }) => {
    if (_id.type === 'income') incomeByMonth[(_id.month || 1) - 1] = total;
    if (_id.type === 'expense') expenseByMonth[(_id.month || 1) - 1] = total;
  });

  const barData = {
    labels: months,
    datasets: [
      { label: 'Income', data: incomeByMonth, backgroundColor: 'rgba(66,190,101,0.7)', borderColor: '#42BE65', borderWidth: 1, borderRadius: 4 },
      { label: 'Expenses', data: expenseByMonth, backgroundColor: 'rgba(250,77,86,0.7)', borderColor: '#FA4D56', borderWidth: 1, borderRadius: 4 },
    ],
  };

  // Chart: line (daily trend from monthly)
  const lineData = {
    labels: months,
    datasets: [
      { label: 'Income', data: incomeByMonth, borderColor: '#42BE65', backgroundColor: 'rgba(66,190,101,0.1)', fill: true, tension: 0.4 },
      { label: 'Expenses', data: expenseByMonth, borderColor: '#FA4D56', backgroundColor: 'rgba(250,77,86,0.1)', fill: true, tension: 0.4 },
    ],
  };

  // Chart: pie
  const pieData = {
    labels: categories.map(c => c._id),
    datasets: [{
      data: categories.map(c => c.total),
      backgroundColor: categories.map((_, i) => CATEGORY_COLORS_ARR[i % CATEGORY_COLORS_ARR.length]),
      borderWidth: 0,
    }],
  };

  const pieOptions = {
    responsive: true,
    plugins: {
      legend: { position: 'right', labels: { color: 'var(--text-secondary)', boxWidth: 12, padding: 16 } },
    },
  };

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-header">Finance Tracker</h1>
          <p className="text-text-muted text-sm">Track income, expenses, and savings</p>
        </div>
        <button onClick={() => navigate('/finance/analytics')} className="btn-secondary">
          <BarChart3 size={16} /> Analytics
        </button>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Today's Income", val: daily.income || 0, color: 'text-accent', icon: TrendingUp },
          { label: "Today's Expenses", val: daily.expense || 0, color: 'text-danger', icon: TrendingDown },
          { label: "Today's Balance", val: (daily.income || 0) - (daily.expense || 0), color: ((daily.income || 0) - (daily.expense || 0)) >= 0 ? 'text-primary' : 'text-danger', icon: Wallet },
        ].map(({ label, val, color, icon: Icon }) => (
          <div key={label} className="card-base flex items-center gap-3">
            <Icon size={20} className={color} />
            <div>
              <p className="text-text-muted text-xs">{label}</p>
              <p className={`font-display font-bold text-lg ${color}`}>{formatCurrency(val)}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Tab Bar */}
      <div className="flex gap-1 bg-surface p-1 rounded-xl border border-border w-fit">
        {TABS.map(({ id, label, icon: Icon }) => (
          <button key={id} onClick={() => setTab(id)}
            className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${
              tab === id ? 'bg-primary text-white' : 'text-text-muted hover:text-text-primary'
            }`}>
            <Icon size={14} /> {label}
          </button>
        ))}
      </div>

      {/* Overview Tab */}
      {tab === 'overview' && (
        <div className="space-y-5">
          <div className="grid lg:grid-cols-2 gap-5">
            <div className="card-base">
              <h3 className="section-title">Monthly Income vs Expenses</h3>
              <Bar data={barData} options={chartOptions} />
            </div>
            <div className="card-base">
              <h3 className="section-title">Spending by Category</h3>
              {categories.length === 0 ? (
                <EmptyState title="No data yet" description="Add some transactions to see your spending breakdown." />
              ) : (
                <Pie data={pieData} options={pieOptions} />
              )}
            </div>
          </div>
          <div className="card-base">
            <h3 className="section-title">Yearly Trend</h3>
            <Line data={lineData} options={chartOptions} />
          </div>
        </div>
      )}

      {/* Add Entry Tab */}
      {tab === 'add' && (
        <div className="card-base max-w-lg">
          <h2 className="section-title">Add Transaction</h2>
          <form onSubmit={handleAdd} className="space-y-4">
            {/* Type Toggle */}
            <div className="flex gap-2">
              {['income', 'expense'].map(t => (
                <button key={t} type="button" onClick={() => setForm(f => ({ ...f, type: t }))}
                  className={`flex-1 py-2.5 rounded-lg text-sm font-medium border transition-all ${
                    form.type === t
                      ? t === 'income' ? 'bg-accent/10 border-accent/40 text-accent' : 'bg-danger/10 border-danger/40 text-danger'
                      : 'border-border text-text-muted hover:text-text-primary'
                  }`}>
                  {t === 'income' ? <TrendingUp size={14} className="inline mr-1" /> : <TrendingDown size={14} className="inline mr-1" />}
                  {t.charAt(0).toUpperCase() + t.slice(1)}
                </button>
              ))}
            </div>

            <div>
              <label className="block text-sm font-medium text-text-secondary mb-1.5">Amount (₹) *</label>
              <input
                type="number"
                value={form.amount}
                onChange={e => setForm(f => ({ ...f, amount: e.target.value }))}
                placeholder="0.00"
                min="0"
                step="0.01"
                className="input-base"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-text-secondary mb-1.5">Category</label>
              <select value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))} className="input-base">
                {FINANCE_CATEGORIES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-text-secondary mb-1.5">Note (optional)</label>
              <input
                value={form.description}
                onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                placeholder="e.g. Hostel rent payment"
                className="input-base"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-text-secondary mb-1.5">Date</label>
              <input
                type="date"
                value={form.date}
                onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
                className="input-base"
              />
            </div>

            <button type="submit" disabled={submitting} className="btn-primary w-full">
              {submitting ? <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <><Plus size={16} /> Add Transaction</>}
            </button>
          </form>
        </div>
      )}

      {/* History Tab */}
      {tab === 'history' && (
        <div className="card-base">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
            <h2 className="section-title mb-0">Transaction History</h2>
            <div className="flex gap-2">
              <select value={typeFilter} onChange={e => { setTypeFilter(e.target.value); setPage(1); }} className="input-base w-auto text-sm py-2">
                <option value="">All Types</option>
                <option value="income">Income</option>
                <option value="expense">Expense</option>
              </select>
              <select value={categoryFilter} onChange={e => { setCategoryFilter(e.target.value); setPage(1); }} className="input-base w-auto text-sm py-2">
                <option value="">All Categories</option>
                {FINANCE_CATEGORIES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
              </select>
            </div>
          </div>

          {txLoading ? <PageSpinner /> : txList.length === 0 ? (
            <EmptyState
              title="No transactions"
              description="Add your first income or expense to get started."
              action={<button onClick={() => setTab('add')} className="btn-primary"><Plus size={16} /> Add Transaction</button>}
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border text-text-muted text-xs uppercase tracking-wider">
                    <th className="text-left py-3 px-2">Date</th>
                    <th className="text-left py-3 px-2">Note</th>
                    <th className="text-left py-3 px-2">Category</th>
                    <th className="text-left py-3 px-2">Type</th>
                    <th className="text-right py-3 px-2">Amount</th>
                    <th className="py-3 px-2" />
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {txList.map((tx) => (
                    <tr key={tx._id} className="hover:bg-surface-2 transition-all">
                      <td className="py-3 px-2 text-text-muted text-xs">{formatDate(tx.date, 'MMM D')}</td>
                      <td className="py-3 px-2 text-text-primary">{tx.description || '—'}</td>
                      <td className="py-3 px-2"><Badge variant="default">{tx.category}</Badge></td>
                      <td className="py-3 px-2"><Badge variant={tx.type === 'income' ? 'accent' : 'danger'}>{tx.type}</Badge></td>
                      <td className={`py-3 px-2 text-right font-semibold ${tx.type === 'income' ? 'text-accent' : 'text-danger'}`}>
                        {tx.type === 'expense' ? '-' : '+'}{formatCurrency(tx.amount)}
                      </td>
                      <td className="py-3 px-2">
                        <button
                          onClick={() => {
                            if (window.confirm('Delete this transaction?')) handleDelete(tx._id);
                          }}
                          className="p-1.5 rounded text-muted hover:text-danger transition-colors"
                        >
                          <Trash2 size={14} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <Pagination currentPage={page} totalPages={pagination.totalPages || 1} onPageChange={setPage} />
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default FinanceTracker;
