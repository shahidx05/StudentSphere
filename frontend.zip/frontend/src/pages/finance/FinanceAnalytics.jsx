import { useState } from 'react';
import useFetch from '../../hooks/useFetch';
import { Doughnut, Line } from 'react-chartjs-2';
import { formatCurrency } from '../../utils/formatCurrency';
import { TrendingUp, TrendingDown, Wallet, Star } from 'lucide-react';
import { PageSpinner } from '../../components/ui/Spinner';

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const CATEGORY_COLORS = ['#FA4D56', '#F1C21B', '#0F62FE', '#42BE65', '#A78BFA', '#6F6F6F', '#FB923C'];

const chartOptions = {
  responsive: true,
  plugins: { legend: { labels: { color: 'var(--text-secondary)', boxWidth: 12 } } },
  scales: {
    x: { grid: { color: 'var(--border)' }, ticks: { color: 'var(--text-muted)' } },
    y: { grid: { color: 'var(--border)' }, ticks: { color: 'var(--text-muted)' } },
  },
};

const FinanceAnalytics = () => {
  const now = new Date();
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [year, setYear] = useState(now.getFullYear());

  const { data: summaryData, loading: summaryLoading } = useFetch(
    `/api/finance/analytics/summary?month=${month}&year=${year}`
  );
  const { data: categoryData } = useFetch('/api/finance/analytics/category');
  const { data: yearlyData } = useFetch('/api/finance/summary/yearly');

  const summary = summaryData?.data || {};
  const categories = categoryData?.data || [];
  const yearly = yearlyData?.data || [];

  // Build line chart data
  const incomeByMonth = Array(12).fill(0);
  const expenseByMonth = Array(12).fill(0);
  yearly.forEach(({ _id, total }) => {
    if (_id.type === 'income') incomeByMonth[(_id.month || 1) - 1] = total;
    if (_id.type === 'expense') expenseByMonth[(_id.month || 1) - 1] = total;
  });

  const lineData = {
    labels: MONTHS,
    datasets: [
      { label: 'Income', data: incomeByMonth, borderColor: '#42BE65', backgroundColor: 'rgba(66,190,101,0.1)', fill: true, tension: 0.4 },
      { label: 'Expenses', data: expenseByMonth, borderColor: '#FA4D56', backgroundColor: 'rgba(250,77,86,0.1)', fill: true, tension: 0.4 },
    ],
  };

  const donutData = {
    labels: categories.map(c => c._id),
    datasets: [{
      data: categories.map(c => c.total),
      backgroundColor: categories.map((_, i) => CATEGORY_COLORS[i % CATEGORY_COLORS.length]),
      borderWidth: 2,
      borderColor: 'var(--surface)',
    }],
  };

  const donutOptions = {
    responsive: true,
    plugins: {
      legend: { position: 'bottom', labels: { color: 'var(--text-secondary)', boxWidth: 12, padding: 12 } },
    },
    cutout: '65%',
  };

  const topCategory = categories.length > 0
    ? categories.reduce((max, c) => c.total > max.total ? c : max, categories[0])
    : null;

  const balance = (summary.totalIncome || 0) - (summary.totalExpense || 0);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="page-header">Finance Analytics</h1>
          <p className="text-text-muted text-sm">Detailed spending breakdown and trends</p>
        </div>
        {/* Month/Year Selector */}
        <div className="flex gap-2">
          <select value={month} onChange={e => setMonth(Number(e.target.value))} className="input-base w-auto text-sm py-2">
            {MONTHS.map((m, i) => <option key={m} value={i + 1}>{m}</option>)}
          </select>
          <select value={year} onChange={e => setYear(Number(e.target.value))} className="input-base w-auto text-sm py-2">
            {[2023, 2024, 2025, 2026].map(y => <option key={y} value={y}>{y}</option>)}
          </select>
        </div>
      </div>

      {summaryLoading ? <PageSpinner /> : (
        <>
          {/* Summary Cards */}
          <div className="grid grid-cols-3 gap-4">
            <div className="card-base flex items-center gap-3">
              <TrendingUp size={20} className="text-accent" />
              <div>
                <p className="text-text-muted text-xs">Total Income</p>
                <p className="font-display font-bold text-lg text-accent">{formatCurrency(summary.totalIncome || 0)}</p>
              </div>
            </div>
            <div className="card-base flex items-center gap-3">
              <TrendingDown size={20} className="text-danger" />
              <div>
                <p className="text-text-muted text-xs">Total Expenses</p>
                <p className="font-display font-bold text-lg text-danger">{formatCurrency(summary.totalExpense || 0)}</p>
              </div>
            </div>
            <div className="card-base flex items-center gap-3">
              <Wallet size={20} className={balance >= 0 ? 'text-primary' : 'text-danger'} />
              <div>
                <p className="text-text-muted text-xs">Net Balance</p>
                <p className={`font-display font-bold text-lg ${balance >= 0 ? 'text-primary' : 'text-danger'}`}>{formatCurrency(balance)}</p>
              </div>
            </div>
          </div>

          {/* Charts Row */}
          <div className="grid lg:grid-cols-2 gap-5">
            {/* Donut */}
            <div className="card-base">
              <h3 className="section-title">Category Breakdown</h3>
              {categories.length === 0 ? (
                <p className="text-text-muted text-sm text-center py-8">No expense data available</p>
              ) : (
                <>
                  <Doughnut data={donutData} options={donutOptions} />
                  {topCategory && (
                    <div className="mt-4 p-3 rounded-xl bg-warning/5 border border-warning/20 flex items-center gap-3">
                      <Star size={16} className="text-warning" />
                      <div>
                        <p className="text-text-muted text-xs">Top Spending Category</p>
                        <p className="text-text-primary font-semibold text-sm capitalize">
                          {topCategory._id} — {formatCurrency(topCategory.total)}
                        </p>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>

            {/* Line */}
            <div className="card-base">
              <h3 className="section-title">Yearly Income vs Expenses</h3>
              <Line data={lineData} options={chartOptions} />
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default FinanceAnalytics;
